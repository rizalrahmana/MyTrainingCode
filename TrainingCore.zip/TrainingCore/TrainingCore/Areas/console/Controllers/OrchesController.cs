﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TrainingCore.Areas.console.Controllers
{
    [Area("console")]
    public class OrchesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Asem()
        {
            return Redirect("/console");
        }
    }
}